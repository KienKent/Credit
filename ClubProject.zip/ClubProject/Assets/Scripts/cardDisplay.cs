﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cardDisplay : MonoBehaviour {

	gameManager gm;
	SpriteRenderer displaySprite;

	// Use this for initialization
	void Start () {
		gm = GameObject.FindGameObjectWithTag("GameController").GetComponent<gameManager>();
		displaySprite = transform.GetChild (0).GetComponent<SpriteRenderer> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (gm.cardPreviewed != null) {
			display (gm.cardPreviewed.GetComponent<SpriteRenderer> ());
		} else {
			display (gm.cardShadowTemplate.GetComponent<SpriteRenderer> ());
		}
	}

	void display(SpriteRenderer source){
		displaySprite.sprite = source.sprite;
		displaySprite.color = source.color;
	}
}
