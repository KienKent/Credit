﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rowScore : MonoBehaviour {

	private int value;
	// Use this for initialization
	void Start () {
		value = 0;
	}

	public void addRowScore(int increment){
		value += increment;
		gameObject.GetComponentInChildren<TextMesh> ().text = "" + value;
		gameObject.GetComponentInParent<totalScore> ().addTotalScore (increment);
	}

	public void minusRowScore(int decrement){
		value -= decrement;
		gameObject.GetComponentInChildren<TextMesh> ().text = "" + value;
		gameObject.GetComponentInParent<totalScore> ().minusTotalScore (decrement);
	}
}	