﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Row : MonoBehaviour {
	
	public List<GameObject> cards;
	bool shadowed;
	GameObject cardShadow;
	public int shadowPosition;
	float spacing = 0.2f;			//Adjustable
	float cardDistance;

	gameManager gm;

	// Use this for initialization
	void Start () {
		cards = new List<GameObject>();
		gm = GameObject.FindGameObjectWithTag("GameController").GetComponent<gameManager>();
		shadowed = false;
		shadowPosition = -1;
		cardDistance = 0.75f + spacing;
	}
	
	// Update is called once per frame
	void Update () {
		if (gm.rowFocused == gameObject && !shadowed) {
			createShadow ();
			sortRow ();
		} else if (shadowed) {
			if (gm.rowFocused != gameObject) {
				destroyShadow ();
				sortRow ();
			} else {
				checkShadowPosition ();
			}
		}
	}

	public bool checkRowFocus(){
		Vector2 diff = Camera.main.ScreenToWorldPoint (Input.mousePosition) - gameObject.transform.position;
		bool isInside = (Mathf.Abs (diff.y) <= 0.5f) && (Mathf.Abs (diff.x) <= 5f);
		if (isInside) {
			gm.rowFocused = this.gameObject;
		}
		return !isInside;
	}

	public void sortRow(){
		float offset = (1 - cards.Count) * (cardDistance / 2);
		for (int i = 0; i < cards.Count; i++) {
			GameObject card = (GameObject)cards [i];
			card.transform.position = new Vector3 ((transform.position.x + offset + (i * cardDistance)), transform.position.y, -1.0f);
		}
	}

	public int getRowScore(){
		int sum = 0;
		foreach (GameObject card in cards) {
			sum += card.GetComponent<Card> ().currentScore ();
		}
		return sum;
	}

	public void addCard(GameObject cardObject){
		Card card = cardObject.GetComponent<Card> ();
		cards.Add (cardObject);
		cardObject.transform.position = cardShadow.transform.position;
		destroyShadow ();
		addScore (card.currentScore ());
	}

	public void addScore(int increment){
		gameObject.GetComponentInParent<rowScore> ().addRowScore (increment);
	}

	public void minusScore(int decrement){
		gameObject.GetComponentInParent<rowScore> ().minusRowScore (decrement);
	}

	void createShadow(){
		cardShadow = Instantiate (gm.cardShadowTemplate);
		cards.Add (cardShadow);
		shadowPosition = cards.Count - 1;
		shadowed = true;
	}

	void destroyShadow(){
		cards.Remove (cardShadow);
		Destroy (cardShadow);
		cardShadow = null;
		shadowPosition = -1;
		shadowed = false;
	}

	void checkShadowPosition(){
		int i;
		Vector2 diff = Camera.main.ScreenToWorldPoint (Input.mousePosition) - gameObject.transform.position;
		if (cards.Count % 2 == 0) {
			i = cards.Count / 2 + Mathf.FloorToInt (diff.x / cardDistance);
		} else {
			i = (cards.Count - 1) / 2 + Mathf.RoundToInt (diff.x / cardDistance);
		}
		if (i >= cards.Count) {
			i = cards.Count - 1;
		} else if (i < 0) {
			i = 0;
		}
		if (i != shadowPosition) {
			cards.Remove (cardShadow);
			cards.Insert (i, cardShadow);
			shadowPosition = i;
			sortRow ();
		}
	}
}
