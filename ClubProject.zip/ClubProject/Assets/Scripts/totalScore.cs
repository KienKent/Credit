﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class totalScore : MonoBehaviour {

	public int value;

	// Use this for initialization
	void Start () {
		value = 0;
	}

	public void addTotalScore(int increment){
		value += increment;
		gameObject.GetComponentInChildren<TextMesh> ().text = "" + value;
	}

	public void minusTotalScore(int decrement){
		value -= decrement;
		gameObject.GetComponentInChildren<TextMesh> ().text = "" + value;
	}
}
