﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CardStatus {Deck, Hand, Field, Graveyard};

public class Card : MonoBehaviour {

	public int id;
	public int baseScore;
	int scoreChanged;
	int type;
	string description;
	CardStatus status;
	bool initialized;

	gameManager gm;
	public Vector3 cardPosition;
	Vector3 offset;

	void Start () {
		scoreChanged = 0;
		initialized = false;
		gm = GameObject.FindGameObjectWithTag("GameController").GetComponent<gameManager>();

		//Testing Purpose
		type = 1;
		description = "A card";
		status = CardStatus.Hand;
	}

	void OnMouseEnter(){
		if (!gm.mouseDown) {
			gm.cardPreviewed = gameObject;
		}
	}

	void OnMouseExit(){
		if (!gm.mouseDown) {
			gm.cardPreviewed = null;
		}
	}

	void OnMouseDown()
	{
		if (status == CardStatus.Hand) {
			cardPosition = gameObject.transform.position;
			offset = gameObject.transform.position - Camera.main.ScreenToWorldPoint (new Vector3 (Input.mousePosition.x, Input.mousePosition.y, 10.0f));
			gm.mouseDown = true;
		}
	}

	void OnMouseDrag()
	{
		if (status == CardStatus.Hand) {
			Vector3 newPosition = new Vector3 (Input.mousePosition.x, Input.mousePosition.y, Camera.main.nearClipPlane + 2);
			transform.position = Camera.main.ScreenToWorldPoint (newPosition) + offset;
		}
	}

	void OnMouseUp()
	{
		if (status == CardStatus.Hand) {
			if (gm.rowFocused != null) {
				Row rowSelected = gm.rowFocused.GetComponent<Row> ();
				gm.rowFocused = null;
				rowSelected.addCard (gameObject);
				status = CardStatus.Field;
				myHand playerHand = gm.selfHand.GetComponent<myHand> ();
				playerHand.cards.Remove (gameObject);
				playerHand.HandArrange ();
			} else {
				transform.position = cardPosition;
			}
			gm.mouseDown = false;
		}
	}

	public bool setCard(int ID, string NAME, int BASESCORE, int TYPE, string DESCRIPTION, CardStatus STATUS){
		if (initialized == false) {
			id = ID;
			name = NAME;
			baseScore = BASESCORE;
			type = TYPE;
			description = DESCRIPTION;
			status = STATUS;

			initialized = true;
			return true;
		} else {
			return false;
		}
	}

	public int getBaseScore(){
		return baseScore;
	}

	public int getScoreChanged(){
		return scoreChanged;
	}

	public int getType(){
		return type;
	}

	public string getDescription(){
		return description;
	}

	public void modifyScore(int scoreIncrement){
		scoreChanged += scoreIncrement;
	}

	public int currentScore(){
		return baseScore + scoreChanged;
	}

	public bool isDead(){
		return baseScore + scoreChanged <= 0;
	}
}
