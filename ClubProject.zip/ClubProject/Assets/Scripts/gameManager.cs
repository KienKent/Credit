﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameManager : MonoBehaviour {
	
	public bool mouseDown;
	public GameObject rowFocused;
	public GameObject cardPreviewed;
	public GameObject cardShadowTemplate;
	public GameObject selfHand;

	GameObject[] rows;

	// Use this for initialization
	void Start () {
		mouseDown = false;
		rows = GameObject.FindGameObjectsWithTag ("SelfBar");
		GameObject[] cards = GameObject.FindGameObjectsWithTag ("Card");
		myHand playerHand = selfHand.GetComponent<myHand> ();
		foreach (GameObject card in cards) {
			playerHand.cards.Add (card);
		}
		playerHand.HandArrange ();
	}
		
	// Update is called once per frame
	void Update () {
		if (mouseDown) { 
			bool noFocus = true;
			foreach (GameObject row in rows) {
				Row r = row.GetComponentInChildren<Row> ();
				if (r != null) {
					noFocus &= r.checkRowFocus ();
				}
			}
			if (noFocus) {
				rowFocused = null;
			}
		}
	}
}
