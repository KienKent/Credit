﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class myHand : MonoBehaviour {

	public List<GameObject> cards;
	Transform left;
	float width;

	// Use this for initialization
	void Start () {
		cards = new List<GameObject>();
		left = this.gameObject.transform.GetChild (0);
		width = 0.5f;
	}

	public void HandArrange(){
		for (int i = 0; i < cards.Count; i++) {
			cards [i].transform.position = new Vector3 ((left.position.x + i * width), transform.position.y, transform.position.z - (float)i/10 - 1);
		}
	}
}
